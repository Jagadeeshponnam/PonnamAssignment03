/**
 * 
 */
/**
 * @author S555255
 *
 */
module PonnamAssignment03 {
	requires java.sql;
}