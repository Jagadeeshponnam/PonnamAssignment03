package ConstructorDeclaredAsFinal;
/**
 * @author S555255 Ponnam Jagadeesh
 *
 * 
 */
public class ConstructorDeclaredAsFinal {
	public static void main(String args[]){
	      int num;
	      final public Sample(){
	         this.num = 30;
	      }
	   }

}
