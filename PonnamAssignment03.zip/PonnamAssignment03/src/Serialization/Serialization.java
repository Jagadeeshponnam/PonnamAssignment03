package Serialization;
import java.io.Serializable;  
/**
 * @author S555255 Ponnam Jagadeesh
 *
 * 
 */
public class Serialization implements Serializable{ 
	  
	 int id;  
	 String name;  
	 public Serialization(int id, String name) {  
	  this.id = id;  
	  this.name = name;  
	 }  

}

