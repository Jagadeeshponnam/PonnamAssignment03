package Testimmutablestring;
/**
 * @author S555255 Ponnam Jagadeesh
 *
 * 
 */
class Testimmutablestring{  
	 public static void main(String args[]){  
	   String s="Jagadeesh";  
	   s.concat("Ponnam");//concat() method appends the string at the end  
	   System.out.println(s);//will print Parimalla because strings are immutable objects  
	 }  
	} 
